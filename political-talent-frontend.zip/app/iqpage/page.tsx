import HeroIq from "@/components/iqpage/hero";
import Footer from "@/components/shared/Footer";
const Iqpage: React.FC = () => {
    return (
       <div> <div className=" py-[100px]">
       <HeroIq />

   </div>
        <Footer/>
   </div>
    );
};

export default Iqpage;
