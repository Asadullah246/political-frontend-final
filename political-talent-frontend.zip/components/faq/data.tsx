
interface FAQItem {
    id: number;
    title: string;
    content: string;
}

const Data: FAQItem[]  = [
    {
        id: 1,
        title: "Will the Mayor send a congratulatory message?",
        content:"Sodales posuere facilisi metus elementum ipsum egestas amet. Mi amet, mattis commodo turpis. Nunc tempor amet massa diam mauris. Risus sodales interdum magna felis, id nunc adipiscing consectetur. Sed consectetur consequat at malesuada tellus."
    },
    {
        id: 2,
        title: "How do I request a proclamation?",
        content:"Sodales posuere facilisi metus elementum ipsum egestas amet. Mi amet, mattis commodo turpis. Nunc tempor amet massa diam mauris. Risus sodales interdum magna felis, id nunc adipiscing consectetur. Sed consectetur consequat at malesuada tellus."
    },{
        id: 3,
        title: "Who can complaint about road parking?",
        content:"Sodales posuere facilisi metus elementum ipsum egestas amet. Mi amet, mattis commodo turpis. Nunc tempor amet massa diam mauris. Risus sodales interdum magna felis, id nunc adipiscing consectetur. Sed consectetur consequat at malesuada tellus."
    },{
        id: 4,
        title:"How can i get property tax bill online?",
        content:"Sodales posuere facilisi metus elementum ipsum egestas amet. Mi amet, mattis commodo turpis. Nunc tempor amet massa diam mauris. Risus sodales interdum magna felis, id nunc adipiscing consectetur. Sed consectetur consequat at malesuada tellus."
    },{
        id: 5,
        title:"Why i make a complaint about specific incidents?",
        content:"Sodales posuere facilisi metus elementum ipsum egestas amet. Mi amet, mattis commodo turpis. Nunc tempor amet massa diam mauris. Risus sodales interdum magna felis, id nunc adipiscing consectetur. Sed consectetur consequat at malesuada tellus."
    },{
        id: 6,
        title:"How can i get property tax bill online?",
        content:"Sodales posuere facilisi metus elementum ipsum egestas amet. Mi amet, mattis commodo turpis. Nunc tempor amet massa diam mauris. Risus sodales interdum magna felis, id nunc adipiscing consectetur. Sed consectetur consequat at malesuada tellus."
    }
]

export default Data;
