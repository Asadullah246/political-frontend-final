import Navigation from "../shared/PageNavigation";

const HeroPolitical: React.FC = () => {
    return (
        <div>
            <Navigation goto="Home" title="Political Talent"/>
        </div>
    );
};

export default HeroPolitical;
