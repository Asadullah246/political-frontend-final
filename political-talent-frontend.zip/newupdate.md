
## point 1  ;

Hi,
Well-done for the work so far done!

But, we are nearly 4 months on this website building, yet we don't seem to be about to have a platform for customers to see. You know we can show customers the profile as it is.

1) The website is TOO SLOW to come up. When you succeed to have it open after many tries, it is so STATIC, especially after the landing page. Clicking the other pages is so un-interacting and dead slow. Something must be wrong and you need to fix it please.

2) Recall that there were minimum features we agreed you place in the website. Some important ones are not there. If they are there, it's difficult to find them. The menu is not well described for users to know what to do, especially the menu at the bottom (Footer menu) on the landing page which should be so many compared to the menu at top (Header menu) on landing page.
Solution:
Please place a DROP DOWN MENU that asks someone "WHAT DO YOU WANT TO DO?" User clicks on it and is given options as below.
1. I need Vetted political talent

2. I am a Constituency/Organization
   2a) Create my profile as constituency or Organization,
   2b) Search for political talent
   2c) Managed Matchmaking
   2d) Need to arrange Training or Workshop or Seminar
   2e) Arrange Consultancy
   2f) Take on Political Apprentices
   2g) Partner with PolitIQ

3) I am a politician (new or experienced)
    3a) Create my profile
    3b) Take PolitIQ Test free
    3c) Apply for political internship
    3d) Councilor courses
    3e) LG Chairmen courses
    3f) House of Assembly member   courses
    3g) House of Representatives member courses
    3e) Senator courses
    3h) Courses for Governors, Presidents, others
3i) Contact PolitIQ for Course Package

4) I want to contribute with curated courses

5) I want to be a Mentor

6) I want to take on Political Apprentices

7) I want to collaborate or partner with PolitIQ

8) I want to go on Political Apprenticeship

9) I want to Partner with PolitIQ

10) I need PolitIQ to build me a Political Team/Staff.

11) I need to contact PolitIQ

It's always a good design to have most of these key menu items scroll past the landing page (starting with this question "WHAT DO YOU WANT TO DO?", some sample Course Titles,  which must be visible on the landing page always), as they are sampled at backend automatically. Please build this in.
It is not clear on the Landing Page what our Services and Offerings are.

4) On the landing page, where we see .... cont'd below


## point 2  :

from different countries like those from Asia and Africa, etc, it's not informative and SHOULD BE REPLACED should be with better information like "what do you want  to do" as above in #3 plus other better information.

5) When you click on most pages, you are asked to SIGN IN. No. You should get information and directions (which our team will add when we get a hold on the Admin dashboard), before being asked to sign in where necessary.
* I was looking for where one can SIGN UP first.

6) Where is the PAYMENT GATEWAY?
It has to be clear to users that they can subscribe to courses and see where it says "SUBSCRIBE FOR COURSES and SERVICES". It has to show also "GET A FREE SUBSCRIPTION", and "See our FREE COURSES HERE", and "TEST YOUR POLITICAL INTELLIGENT QUOTIENT WITH PolitIQ Test (Free)", and "REFER OTHERS and get a REWARD"

7) Where is the SITE MAP for the website, so one can use that to know what there is?

8) When are we getting the access to the DASHBOARD so as to start uploading stuff when you tell us what to do?

9) Please provide for us here the complete SOURCE CODE. Thx.

10) These are our INITIAL OBSERVATIONS . We will send more as we see them.

## point 3 :

I have raised 10 points above needing your attention. Please carefully look at fixing them. We are behind time. Thx

LET ME BE CLEAR.
I am not saying that you replace the TOP (HEADER) MENU where you already have "About us".. "PolitIQ Test", etc with "WHAT DO YOU WANT TO DO" and it's drop down menu. Rather, provide a separate portion on the landing page for the "WHAT DO YOU WHAT TO DO" with it's drop down menu comprising 11 options of what can be done. I suggested that you can REPLACE the area where you have pictures of what's happening in countries from Asia and Africa at middle of landing page with this "WHAT DO YOU WANT TO DO" and drop down menu" + samples courses and services scrolling past..



// import { NextResponse } from "next/server";
// require('dotenv').config();
// const mysql = require('mysql2/promise'); // Using promise-based version

// const pool = mysql.createPool(process.env.DATABASE_SERVER);
// console.log('Connected to PlanetScale!');

// export async function GET(request) {
//   console.log("calling this get method");

//   const data = [
//     {
//       name: "dkjfd",
//       use: "djfd",
//     },
//     {
//       name: "dkjfdfd",
//       use: "ddffjfd",
//     },
//   ];

//   try {
//     const connection = await pool.getConnection();
//     const res = await connection.query('SELECT * FROM Category');
//     connection.release();
//     console.log("re", res)
//     // return NextResponse.json(data);
//   } catch (error) {
//     console.error(error);
//     return NextResponse.json({ message: error }, { status: 500 });
//   }
// }

// import { PrismaClient } from "@prisma/client";

// const prisma = new PrismaClient();

// export async function GET(request) {
//   console.log("calling this get method");

//   try {
//     const categories = await prisma.course.findMany();
//     return NextResponse.json(categories);
//   } catch (error) {
//     console.error('Error fetching data from Prisma:', error);
//     return NextResponse.json({ message: "Internal Server Error" }, { status: 500 });
//   }
// }


// export function POST(request) {
//   // Your POST logic here
// }

// export function PUT(request) {
//   // Your PUT logic here
// }

// export function DELETE(request) {
//   // Your DELETE logic here
// }
