npx prisma migrate reset
 npx prisma db push
